package com.jsaravia.proyectocapstone

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a los campos de entrada
        val inputField1: EditText = findViewById(R.id.dato1)
        val inputField2: EditText = findViewById(R.id.dato2)
        val inputField3: EditText = findViewById(R.id.dato3)
        val inputField4: EditText = findViewById(R.id.dato4)
        val inputField5: EditText = findViewById(R.id.dato5)
        val inputField6: EditText = findViewById(R.id.dato6)

        // Referencias al botón y el texto de resultado
        val predictButton: Button = findViewById(R.id.btnPredecir)
        val resultText: TextView = findViewById(R.id.txtResultado)

        try {
            // Inicializa ModelInference con el modelo ONNX
            val assetManager = assets
            val modelInference = ModelInference(assetManager, "modelo_random_forest.onnx")

            // Configura el botón para procesar la predicción
            predictButton.setOnClickListener {
                // Obtén los valores ingresados por el usuario
                val dato1 = inputField1.text.toString().toFloatOrNull() ?: 0f
                val dato2 = inputField2.text.toString().toFloatOrNull() ?: 0f
                val dato3 = inputField3.text.toString().toFloatOrNull() ?: 0f
                val dato4 = inputField4.text.toString().toFloatOrNull() ?: 0f
                val dato5 = inputField5.text.toString().toFloatOrNull() ?: 0f
                val dato6 = inputField6.text.toString().toFloatOrNull() ?: 0f

                // Crea el arreglo de entrada para el modelo
                val inputFeatures = floatArrayOf(dato1, dato2, dato3, dato4, dato5, dato6)

                // Llama al método `predict` y muestra el resultado
                val prediction = modelInference.predict(inputFeatures)
                resultText.text = "Resultado de la predicción: ${prediction.joinToString(", ")}"
            }

        } catch (e: IOException) {
            e.printStackTrace()
            resultText.text = "Error al cargar el modelo: ${e.message}"
        }
    }
}
